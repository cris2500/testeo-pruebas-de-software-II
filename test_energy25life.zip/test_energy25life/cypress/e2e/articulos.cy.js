describe('test HU-001', ()=>{
    beforeEach(()=>{
        cy.intercept('GET', '').as('loadPageIndex')
        cy.visit('')
    })
    //caso de prueba CYP-001::tamaño de pantalla para verificar diseño responsive
    it('Verifico que la tarjeta de los articulos sea responsive', ()=>{
        cy.wait('@loadPageIndex')

        cy.viewport(1200, 800)
        //assertions 1200, 800
        cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'row') 
        cy.get('.intro_articulo img').should('have.css', 'width', '452.84375px')       
        //assertions 720, 800
        cy.viewport(720, 800)
        cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'column')
        cy.viewport(320, 800)
        cy.get('.contenedor_flex .intro_articulo').should('have.css', 'width', '275px')
    })

    //caso de prueba CYP-002::accedo al contenido de un articulo
    it('Accedo al enlace del articulo', ()=>{
        //pasos del test del escenario
        cy.wait('@loadPageIndex')

        cy.intercept('GET', '/psicologia/blandit-lacus-consequat-ut').as('loadPageArticle')

        cy.get(
            'a[href="https://www.energy25life.com/psicologia/blandit-lacus-consequat-ut"] button[type="button"]'
        ).contains('Leer Más').click()
        
        cy.wait('@loadPageArticle') 
    })

    //caso de prueba CYP-003::verifico diseño de la pagina de articulo en diferentes tamaños de pantalla y accedo a otro articulo relacionado
    it('Contenido de articulo responsive y accedo a otro articulo relacionado', ()=>{
        cy.wait('@loadPageIndex')

        cy.intercept('GET', '/psicologia/blandit-lacus-consequat-ut').as('loadPageArticle')
        
        cy.visit('/psicologia/blandit-lacus-consequat-ut')
        
        cy.wait('@loadPageArticle')

        cy.viewport(1200, 800)
        
        cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'row')

        cy.viewport(720, 800)

        cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'column')

        cy.viewport(320, 800)

        cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'column')

        //recomendar articulos
        cy.get('.avanzar_retroceder_articulo').should('be.visible')
        //intercerto la peticion get al anterior articulo con un alias
        cy.intercept('GET', '/psicologia/morbi-eleifend-ante-tincidunt-elit').as('loadBackArticle')
        //identificar si hay articulos siguientes o anteriores a su publicacion
        //como es el ultimo articulo publicado se espera que no halla next_article
        cy.get('.avanzar_retroceder_articulo .next_aerticle a').should('not.exist')
        
        cy.get('.avanzar_retroceder_articulo .back_article a[href="https://www.energy25life.com/psicologia/morbi-eleifend-ante-tincidunt-elit"]').should('be.visible').click()
        //Carga la peticion get al articulo anterior
        cy.wait('@loadBackArticle')
    })

})