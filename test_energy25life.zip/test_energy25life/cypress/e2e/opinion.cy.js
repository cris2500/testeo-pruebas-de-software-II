describe('Test HU-005', ()=>{

    beforeEach(()=>{
        cy.intercept('GET', '/nutricion/proin-sed-massa-augue').as('getArticle')
        cy.visit('/nutricion/proin-sed-massa-augue')    
    })

    it('CYP-012 El formulario de opinión al articulo debe indicarme cuando los campos no cumplen con las validaciones', ()=>{
        
        cy.wait('@getArticle')
        
        cy.get('input[name="nombre_opinion"]').invoke('removeAttr', 'required')

        cy.get('input[name="email_opinion"]').invoke('removeAttr', 'required')
        
        cy.get('input[name="email_opinion"]').invoke('removeAttr', 'type')

        cy.get('textarea[name="contenido_opinion"]').invoke('removeAttr', 'required')
        
        cy.get('input[name="nombre_opinion"]').should('be.visible').type('%&$%&%$%&>><?php >')

        cy.get('input[name="email_opinion"]').should('be.visible').type('dasd<>dsad@dasdasd.com')

        cy.get('textarea[name="contenido_opinion"]').should('be.visible').type('<?php ?> asdasd<>&%$/&%$$&')

        cy.get('input[type="submit"]').should('be.visible').click()

        cy.get('div[class="notie-textbox-inner"]').should('be.visible')

    })

    /*it('CYP-013, El formulario de opinión debe recibir una opinion que cumpla con las condiciones', ()=>{

        cy.wait('@getArticle')
        
        cy.get('input[name="nombre_opinion"]').should('be.visible').type('Andres Castro')

        cy.get('input[name="email_opinion"]').should('be.visible').type('correo@gmail.com')

        cy.get('textarea[name="contenido_opinion"]').should('be.visible').type('El articulo esta genial')

        cy.get('input[type="submit"]').should('be.visible').click()

        cy.get('div[class="notie-textbox-inner"]').should('be.visible')

    })*/

    it('CYP-014 la opinion debe ser aprobada por un administrador', ()=>{
        
        cy.login()

        cy.intercept('GET', '/cms/public/opiniones').as('getOpiniones')

        cy.visit('/cms/public/opiniones')

        cy.get('.sorting_1').eq(0).should('be.visible').click()

        cy.intercept('GET', 'cms/public/opiniones/16').as('getOpinionEdit')

        cy.get('a[href="https://www.energy25life.com/cms/public/opiniones/16"]').eq(1).should('be.visible').click()

        cy.wait('@getOpinionEdit')

        cy.get('textarea[name="contenido_rpta"]').scrollIntoView().should('be.visible').clear()

        cy.get('textarea[name="contenido_rpta"]').scrollIntoView().should('be.visible').type('Si es una información reciente que te ayudara mucho amigo')

        cy.intercept('POST', 'cms/public/opiniones/16').as('postOpinionEdit')

        cy.contains('Guardar').click()

        cy.wait('@postOpinionEdit')

        cy.get('.notie-textbox-inner').contains('Se han guardado los cambios').should('be.visible')

        cy.wait('@getOpiniones')

    })

    it('CYP-015, se comprueba despues de que la opinion fue aprobada y respondida que se visualice en el articulo correspondiente', ()=>{

        cy.wait('@getArticle')
        cy.get('.usuario_opinion').should('be.visible')
        cy.get('.admin_opinion').should('be.visible')

    })


})