describe('test HU-004', ()=>{
    
    beforeEach(()=>{
        cy.intercept('GET', '/cms/public/').as('getLogin')    
        cy.visit('/cms/public/')
    })


    it('CYP-009 ingreso a la pagina de login validacion de campos vacios', ()=>{
        cy.wait('@getLogin')

        cy.get('input[name="email"]').should('be.visible').invoke('removeAttr', 'required')

        cy.get('input[name="password"]').should('be.visible').invoke('removeAttr', 'required')

        //cy.get('.recaptcha-checkbox').click()

        cy.intercept('POST', '/cms/public/login').as('postLogin')

        cy.get('button[type="submit"]').should('be.visible').click()
        
        cy.wait('@postLogin')

        cy.contains('El campo correo electrónico es obligatorio').should('be.visible')

        cy.contains('El campo contraseña es obligatorio.').should('be.visible')

    })

    it('CYP-010 ingreso a la pagina de login con credenciales no validas', ()=>{
        
        cy.wait('@getLogin')

        cy.get('input[name="email"]').should('be.visible').invoke('removeAttr', 'type')

        cy.get('input[name="email"]').should('be.visible').type('%?<>testLogin')

        cy.get('input[name="password"]').should('be.visible').type('&%??testLogin')

        cy.intercept('POST', '/cms/public/login').as('postLogin')

        cy.get('button[type="submit"]').should('be.visible').click()

        cy.wait('@postLogin')

        //busgs en la aplicación realiza la busqueda admitiendo caracteres peligrosos para la base de datos
        cy.contains('El correo electrónico tiene caracteres no validos en la aplicación.').should('be.visible')

        cy.contains('La contraseña tiene caracteres no validos en la aplicación.').should('be.visible')

    })

    it('CYP-011 ingresa al dashboard con exito, agregando las credenciales correctas', ()=>{

        cy.wait('@getLogin')

        cy.get('input[name="email"]').should('be.visible').invoke('removeAttr', 'type')

        cy.get('input[name="email"]').should('be.visible').type('cristian.tllez25@gmail.com')

        cy.get('input[name="password"]').should('be.visible').type('Admin12345')

        cy.intercept('POST', '/cms/public/login').as('postLogin')

        cy.get('button[type="submit"]').should('be.visible').click()

        cy.wait('@postLogin')

        cy.contains('Panel de control').should('be.visible')

    })

})