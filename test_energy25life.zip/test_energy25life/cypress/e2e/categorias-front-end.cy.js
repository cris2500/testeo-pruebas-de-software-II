describe('test HU-002', ()=>{
    beforeEach(()=>{
        cy.intercept('GET', '').as('pageIndex')
        cy.visit('/')
    })

    //caso de prueba::CYP-004
    it('CYP-004 verifico que exista la categoria en el menu y luego accedo a esta', ()=>{
        //verifico que cargue la peticion get de la pagina de index
        cy.wait('@pageIndex')
        cy.get('i.fa-bars').should('be.visible').click()        
        cy.intercept('GET', '/introduccion').as('pageCategoria')
        cy.get('nav.menu ul li a[href="https://www.energy25life.com/introduccion"]').should('be.visible').click()
        cy.wait('@pageCategoria')
        cy.get('main.contenido_principal h1').contains('Introducción').should('be.visible')
    })

    //caso de prueba::CYP-005
    it('CYP-005 verifico verifico que la pagina de catgoria sea responsive y que tenga los articulos relacionados a esta', ()=>{
        //verifico que cargue la peticion get de la pagina index
        cy.wait('@pageIndex')
        //interceto la peticion get y le agrego un alias
        cy.intercept('GET', '/introduccion').as('pageCategoria')
        cy.visit('/introduccion')
        //verifico que carge la pagina de categoria
        cy.wait('@pageCategoria')
        //verifico que contenga los articulos
        cy.get('article.intro_articulo').should('be.visible')
        //verifico que tenga el breadcrumb y que funcione
        cy.get('.breadcrumb li.inicio').should('be.visible').click()
        //espero que cargue la pagina de index
        cy.wait('@pageIndex')
        //redirijo que a categoria
        cy.visit('/introduccion')
        //espero que cargue la pagina de categoria
        cy.wait('@pageCategoria')
        //verifico que la pagina sea responsive
        cy.responsiveDesign()

    })

    

})