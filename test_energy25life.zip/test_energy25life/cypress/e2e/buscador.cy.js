describe('test HU-003', ()=>{

    beforeEach( ()=>{
        cy.intercept('GET', '/').as('getIndex')
        cy.visit('/')
    })

    it('CYP-006, buscador debe ser responsive para diferentes dispositivos', ()=>{

        cy.wait('@getIndex')

        cy.viewport(1200, 800)

        cy.get('.fa-search').should('be.visible')
        
        cy.get('input[name="search"]').should('not.be.visible')

        cy.viewport(767, 800)

        cy.get('.fa-search[data-target="#buscador"]').should('not.be.visible')
        
        cy.get('input[name="search"]').should('be.visible')

        cy.viewport(320, 800)

        cy.get('.fa-search[data-target="#buscador"]').should('not.be.visible')
        
        cy.get('input[name="search"]').should('be.visible')

    })

    it('CYP-007, el buscador debe realizar busquedas de articulos relacionados a mi busqueda', ()=>{

        cy.get('i[data-target="#buscador"]').click()

        cy.get('input[name="search"]').eq(0).should('be.visible').type('alimentos')

        cy.intercept('GET', '/alimentos').as('getSearch')

        cy.get('.buscar').eq(0).should('be.visible').click()

        cy.wait('@getSearch')

        cy.get('.contenedor_flex main.contenido_principal article.intro_articulo').should('be.visible')
        
        
    })

    it('CYP-008, el buscador debe decirme cuando no hay resultados en mi busqueda', ()=>{
        
        cy.wait('@getIndex')

        cy.get('i[data-target="#buscador"]').click()

        cy.get('input[name="search"]').eq(0).should('be.visible').type('cajas')

        cy.intercept('GET', '/cajas').as('getSearch')

        cy.get('.buscar').eq(0).should('be.visible').click()

        cy.wait('@getSearch')

        cy.contains('No se han encontrado coicidencias...').should('be.visible')

    })

})