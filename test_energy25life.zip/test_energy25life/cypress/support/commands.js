// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

Cypress.Commands.add('responsiveDesign', ()=>{

    cy.viewport(1200, 800)
    cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'row')
    cy.viewport(768, 800)
    cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'column')
    cy.viewport(320, 800)
    cy.get('.contenedor_flex').should('have.css', 'flex-direction', 'column')

})

//incio de session para los test en el dashboard
Cypress.Commands.add('login', ()=>{
    cy.intercept('GET', '/cms/public/').as('getLogin')    
    
    cy.visit('/cms/public/')

    cy.wait('@getLogin')

    cy.get('input[name="email"]').should('be.visible').invoke('removeAttr', 'type')

    cy.get('input[name="email"]').should('be.visible').type('cristian.tllez25@gmail.com')

    cy.get('input[name="password"]').should('be.visible').type('Admin12345')

    cy.intercept('POST', '/cms/public/login').as('postLogin')

    cy.get('button[type="submit"]').should('be.visible').click()

    cy.wait('@postLogin')

    cy.contains('Panel de control').should('be.visible')

})